// Wait for the DOM content to be fully loaded
document.addEventListener("DOMContentLoaded", () => {
    // Get references to the button and the fact container
    const fetchFactBtn = document.getElementById("fetchFactBtn"); // Button to fetch facts
    const catFactElement = document.getElementById("catFact"); // Paragraph to display the fact

    // Add an event listener to the button for clicks
    fetchFactBtn.addEventListener("click", () => {
        fetchCatFact(); // Call the function to fetch a cat fact
    });

    // Function to fetch a cat fact from the API
    function fetchCatFact() {
        // API endpoint for cat facts
        const apiUrl = "https://catfact.ninja/fact";

        // Fetch data from the API
        fetch(apiUrl)
            .then(response => {
                // Check if the response is successful
                if (!response.ok) {
                    throw new Error("Network response was not ok");
                }
                return response.json(); // Parse JSON response
            })
            .then(data => {
                // Update the paragraph with the fetched cat fact
                catFactElement.textContent = data.fact;
            })
            .catch(error => {
                // Handle any errors that occur during the fetch
                console.error("Error fetching cat fact:", error);
                catFactElement.textContent = "Oops! Unable to fetch a cat fact. Please try again.";
            });
    }
});
