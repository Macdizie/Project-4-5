# Import necessary gRPC libraries
import grpc  # gRPC library for client-server communication
import quadratic_pb2  # Generated classes for protocol buffers (data structures)
import quadratic_pb2_grpc  # Generated classes for gRPC services

# Define the main function to run the gRPC client
def run():
    # Create a channel to connect to the gRPC server on the specified address and port
    # The connection here is insecure; in production, secure channels should be used
    with grpc.insecure_channel('localhost:50051') as channel:
        # Create a stub (client) for the QuadraticSolver service
        # The stub allows us to call the remote methods defined in the server
        stub = quadratic_pb2_grpc.QuadraticSolverStub(channel)
        
        # Define example coefficients for the quadratic equation ax^2 + bx + c = 0
        a, b, c = 2, 3, -2  # Coefficients for the equation
        
        # Make a request to the SolveQuadratic method of the server
        # The request includes the coefficients a, b, and c, which are packaged in a QuadraticRequest object
        response = stub.SolveQuadratic(quadratic_pb2.QuadraticRequest(a=a, b=b, c=c))
        
        # Print the solution received from the server
        # The server response contains the solutions to the quadratic equation
        print(response.solution)

# Check if this script is run as the main program
# If so, call the run function to execute the gRPC client
if __name__ == '__main__':
    run()
