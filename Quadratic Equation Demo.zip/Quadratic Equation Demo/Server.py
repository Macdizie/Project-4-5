# Import necessary libraries and modules
from concurrent import futures  # For creating a pool of threads to handle multiple client requests
import grpc  # gRPC library for setting up server-client communication
import quadratic_pb2  # Generated classes for protocol buffers (data structures)
import quadratic_pb2_grpc  # Generated classes for gRPC services
import math  # For mathematical operations like square root calculation

# Define a class for the QuadraticSolver service, implementing the server-side logic
class QuadraticSolverServicer(quadratic_pb2_grpc.QuadraticSolverServicer):
    # Implement the SolveQuadratic method, which is part of the gRPC service
    def SolveQuadratic(self, request, context):
        # Extract the coefficients a, b, and c from the client's request
        a, b, c = request.a, request.b, request.c
        
        # Calculate the discriminant (b^2 - 4ac) to determine the nature of the roots
        discriminant = b**2 - 4*a*c
        
        # Check if the discriminant is non-negative (indicating real roots)
        if discriminant >= 0:
            # Calculate both roots of the quadratic equation using the quadratic formula
            root1 = (-b + math.sqrt(discriminant)) / (2*a)
            root2 = (-b - math.sqrt(discriminant)) / (2*a)
            # Format the solution as a string to return to the client
            solution = f"The solutions are {root1} and {root2}"
        else:
            # If the discriminant is negative, there are no real roots
            solution = "There are no real solutions"
        
        # Return the result as a QuadraticResponse, including the solution string
        return quadratic_pb2.QuadraticResponse(solution=solution)

# Define a function to start and run the gRPC server
def serve():
    # Create a gRPC server with a pool of threads to handle multiple requests simultaneously
    server = grpc.server(futures.ThreadPoolExecutor(max_workers=10))
    
    # Register the QuadraticSolverServicer with the gRPC server
    quadratic_pb2_grpc.add_QuadraticSolverServicer_to_server(QuadraticSolverServicer(), server)
    
    # Set the server to listen for client connections on port 50051
    # The address '[::]' allows the server to accept requests from any IP
    server.add_insecure_port('[::]:50051')
    
    # Start the server to begin accepting client connections
    server.start()
    
    # Keep the server running indefinitely, waiting for incoming requests
    server.wait_for_termination()

# If this script is run as the main program, start the gRPC server
if __name__ == '__main__':
    serve()
