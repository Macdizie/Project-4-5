/* 
Drop the database if it exists 
This ensures a clean start by removing the existing database
*/
DROP DATABASE IF EXISTS CRM_System;

/* 
Create Database 
If the database CRM_System does not exist, create it
*/
CREATE DATABASE IF NOT EXISTS CRM_System;
USE CRM_System;

/* 
Drop existing tables if they exist 
This ensures that old tables are removed before creating new ones
*/
-- We will ignore the warnings and proceed
SET SESSION sql_notes = 0;

DROP TABLE IF EXISTS UserRole;  
DROP TABLE IF EXISTS Role;  
DROP TABLE IF EXISTS `User`;  
DROP TABLE IF EXISTS OrderDetails;  
DROP TABLE IF EXISTS `Order`;  
DROP TABLE IF EXISTS Product;  
DROP TABLE IF EXISTS Customer;  
DROP TABLE IF EXISTS Supplier;
DROP TABLE IF EXISTS Inventory;

SET SESSION sql_notes = 1;

/* 
Create User Table 
This table stores user information, including UserID, first name, last name, email, phone number, date of birth, and address.
UserID is the primary key and auto-incremented.
Email is unique to ensure no duplicates.
*/
CREATE TABLE `User` (
    UserID INT AUTO_INCREMENT PRIMARY KEY, 
    FirstName VARCHAR(50) NOT NULL, 
    LastName VARCHAR(50) NOT NULL, 
    Email VARCHAR(100) UNIQUE NOT NULL, 
    Phone VARCHAR(20), 
    DateOfBirth DATE, 
    Address VARCHAR(255)
);

/* 
Create Role Table 
This table stores different roles that users can have.
RoleID is the primary key and auto-incremented.
*/
CREATE TABLE Role (
    RoleID INT AUTO_INCREMENT PRIMARY KEY, 
    RoleName VARCHAR(50) NOT NULL
);

/* 
Create UserRole Table 
This table links users to their roles using a many-to-many relationship.
UserID and RoleID together form the primary key.
Foreign keys ensure data integrity by referencing the User and Role tables.
*/
CREATE TABLE UserRole (
    UserID INT, 
    RoleID INT, 
    PRIMARY KEY (UserID, RoleID), 
    FOREIGN KEY (UserID) REFERENCES `User`(UserID),
    FOREIGN KEY (RoleID) REFERENCES Role(RoleID)
);

/* 
Create Customer Table 
This table stores customer information, including CustomerID, first name, last name, email, phone number, and address.
CustomerID is the primary key and auto-incremented.
Email is unique to ensure no duplicates.
*/
CREATE TABLE Customer (
    CustomerID INT AUTO_INCREMENT PRIMARY KEY, 
    FirstName VARCHAR(50) NOT NULL, 
    LastName VARCHAR(50) NOT NULL, 
    Email VARCHAR(100) UNIQUE NOT NULL, 
    Phone VARCHAR(20), 
    Address VARCHAR(255)
);

/* 
Create Product Table 
This table stores product information, including ProductID, product name, category, and price.
ProductID is the primary key and auto-incremented.
Price is a decimal value to accommodate currency values.
*/
CREATE TABLE Product (
    ProductID INT AUTO_INCREMENT PRIMARY KEY, 
    ProductName VARCHAR(100) NOT NULL, 
    Category VARCHAR(50) NOT NULL, 
    Price DECIMAL(10, 2) NOT NULL
);

/* 
Create Order Table 
This table stores order information, including OrderID, CustomerID, order date, and total amount.
OrderID is the primary key and auto-incremented.
CustomerID is a foreign key that references the Customer table.
TotalAmount is a decimal value to accommodate currency values.
*/
CREATE TABLE `Order` (
    OrderID INT AUTO_INCREMENT PRIMARY KEY, 
    CustomerID INT NOT NULL, 
    OrderDate DATE NOT NULL, 
    TotalAmount DECIMAL(10, 2) NOT NULL, 
    FOREIGN KEY (CustomerID) REFERENCES Customer(CustomerID)
);

/* 
Create OrderDetails Table 
This table stores details of each order, including OrderDetailID, OrderID, ProductID, quantity, and total price.
OrderDetailID is the primary key and auto-incremented.
OrderID is a foreign key that references the Order table.
ProductID is a foreign key that references the Product table.
TotalPrice is a decimal value to accommodate currency values.
*/
CREATE TABLE OrderDetails (
    OrderDetailID INT AUTO_INCREMENT PRIMARY KEY, 
    OrderID INT NOT NULL, 
    ProductID INT NOT NULL, 
    Quantity INT NOT NULL, 
    TotalPrice DECIMAL(10, 2) NOT NULL, 
    FOREIGN KEY (OrderID) REFERENCES `Order`(OrderID), 
    FOREIGN KEY (ProductID) REFERENCES Product(ProductID)
);

/* 
Create Supplier Table 
This table stores supplier information, including SupplierID, supplier name, contact name, phone number, and address.
SupplierID is the primary key and auto-incremented.
*/
CREATE TABLE Supplier (
    SupplierID INT AUTO_INCREMENT PRIMARY KEY, 
    SupplierName VARCHAR(100) NOT NULL, 
    ContactName VARCHAR(50), 
    Phone VARCHAR(20), 
    Address VARCHAR(255)
);

/* 
Create Inventory Table 
This table stores inventory information, including InventoryID, ProductID, and quantity in stock.
InventoryID is the primary key and auto-incremented.
ProductID is a foreign key that references the Product table.
*/
CREATE TABLE Inventory (
    InventoryID INT AUTO_INCREMENT PRIMARY KEY, 
    ProductID INT NOT NULL, 
    QuantityInStock INT NOT NULL, 
    FOREIGN KEY (ProductID) REFERENCES Product(ProductID)
);

