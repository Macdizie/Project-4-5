-- Drop the MusicCollection database if it exists
DROP DATABASE IF EXISTS MusicCollection;

-- Create the MusicCollection database
CREATE DATABASE MusicCollection;
USE MusicCollection;

-- Create the Users table to store user information
CREATE TABLE IF NOT EXISTS Users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(255) NOT NULL UNIQUE,
    email VARCHAR(255) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL
);

-- Create the Artists table to store artist information
CREATE TABLE IF NOT EXISTS Artists (
    artist_id INT AUTO_INCREMENT PRIMARY KEY,
    artist_name VARCHAR(255) NOT NULL,
    biography TEXT,
    social_media_links TEXT
);

-- Create the Albums table to store album information with a foreign key reference to Artists
CREATE TABLE IF NOT EXISTS Albums (
    album_id INT AUTO_INCREMENT PRIMARY KEY,
    album_name VARCHAR(255) NOT NULL,
    artist_id INT REFERENCES Artists(artist_id) ON DELETE CASCADE,
    release_year INT,
    genre VARCHAR(100),
    label VARCHAR(100)
);

-- Create the Songs table to store song information with a foreign key reference to Albums
CREATE TABLE IF NOT EXISTS Songs (
    song_id INT AUTO_INCREMENT PRIMARY KEY,
    album_id INT REFERENCES Albums(album_id) ON DELETE CASCADE,
    title VARCHAR(255) NOT NULL,
    duration TIME,
    lyrics TEXT,
    composer VARCHAR(255),
    producer VARCHAR(255)
);

-- Create the Reviews table to store album reviews with foreign key references to Users and Albums
CREATE TABLE IF NOT EXISTS Reviews (
    review_id INT AUTO_INCREMENT PRIMARY KEY,
    album_id INT REFERENCES Albums(album_id) ON DELETE CASCADE,
    user_id INT REFERENCES Users(user_id) ON DELETE CASCADE,
    review TEXT,
    rating INT CHECK (rating >= 1 AND rating <= 5)
);

-- Create the Playlists table to store playlist information with a foreign key reference to Users
CREATE TABLE IF NOT EXISTS Playlists (
    playlist_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT REFERENCES Users(user_id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    description TEXT
);

-- Create the PlaylistSongs table to store the relationship between Playlists and Songs
CREATE TABLE IF NOT EXISTS PlaylistSongs (
    playlist_id INT REFERENCES Playlists(playlist_id) ON DELETE CASCADE,
    song_id INT REFERENCES Songs(song_id) ON DELETE CASCADE,
    PRIMARY KEY (playlist_id, song_id)
);

-- Create the SharedPlaylists table to store shared playlists between users
CREATE TABLE IF NOT EXISTS SharedPlaylists (
    playlist_id INT REFERENCES Playlists(playlist_id) ON DELETE CASCADE,
    user_id INT REFERENCES Users(user_id) ON DELETE CASCADE,
    shared_with_user_id INT REFERENCES Users(user_id) ON DELETE CASCADE,
    PRIMARY KEY (playlist_id, user_id, shared_with_user_id)
);

-- Drop roles if they already exist to avoid errors during creation
DROP ROLE IF EXISTS read_only_role;
DROP ROLE IF EXISTS modification_role;

-- Create roles
CREATE ROLE read_only_role;
CREATE ROLE modification_role;

-- Assign permissions to roles
GRANT SELECT ON MusicCollection.* TO read_only_role;
GRANT INSERT, UPDATE, DELETE ON MusicCollection.* TO modification_role;

-- Drop users if they already exist to avoid warnings
DROP USER IF EXISTS 'readonly_user'@'localhost';
DROP USER IF EXISTS 'modification_user'@'localhost';

-- Create users and assign roles
CREATE USER 'readonly_user'@'localhost' IDENTIFIED BY 'readonlypassword';
CREATE USER 'modification_user'@'localhost' IDENTIFIED BY 'modificationpassword';
GRANT read_only_role TO 'readonly_user'@'localhost';
GRANT modification_role TO 'modification_user'@'localhost';

-- Ensure privileges are applied
FLUSH PRIVILEGES;

-- Adding indexes to improve query performance on relevant columns
CREATE INDEX idx_album_id ON Songs(album_id);
CREATE INDEX idx_user_id ON Playlists(user_id);
CREATE INDEX idx_shared_user_id ON SharedPlaylists(shared_with_user_id);