-- Suppress warnings
SET sql_mode = '';

USE MusicCollection;

-- Drop existing procedures and functions if they exist
DROP PROCEDURE IF EXISTS GetTopRatedSongs;
DROP FUNCTION IF EXISTS GetAverageRating;
DROP PROCEDURE IF EXISTS GetAlbumComments;
DROP PROCEDURE IF EXISTS AddSongToPlaylist;
DROP PROCEDURE IF EXISTS RateSong;
DROP PROCEDURE IF EXISTS AddFavoriteSong;
DROP PROCEDURE IF EXISTS AddFavoriteAlbum;
DROP PROCEDURE IF EXISTS IncrementSongPlayCount;
DROP PROCEDURE IF EXISTS AddAlbumReview;
DROP PROCEDURE IF EXISTS SharePlaylist;

-- Reset SQL mode to the default value
SET sql_mode = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION,NO_ZERO_DATE,NO_ZERO_IN_DATE,ERROR_FOR_DIVISION_BY_ZERO';

-- Set the delimiter to $$ to allow for the creation of procedures and functions
DELIMITER $$

-- Procedure to get top-rated songs for an album
CREATE PROCEDURE GetTopRatedSongs(IN albumId INT, IN limitCount INT)
BEGIN
    -- Validate input parameters
    IF albumId IS NULL OR limitCount IS NULL OR limitCount <= 0 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Invalid input parameters for GetTopRatedSongs';
    END IF;

    -- Select song titles and their average ratings
    SELECT s.title, AVG(r.rating) AS average_rating
    FROM songs s
    JOIN user_ratings r ON s.song_id = r.song_id
    WHERE s.album_id = albumId  -- Filter by album ID
    GROUP BY s.title  -- Group by song title
    ORDER BY average_rating DESC  -- Order by average rating in descending order
    LIMIT limitCount;  -- Limit the number of results
END $$

-- Function to calculate the average rating of a song
CREATE FUNCTION GetAverageRating(songId INT) RETURNS DECIMAL(3, 2)
DETERMINISTIC
READS SQL DATA
BEGIN
    DECLARE avgRating DECIMAL(3, 2);

    -- Validate input parameters
    IF songId IS NULL THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Invalid input parameter for GetAverageRating';
    END IF;

    -- Select the average rating of the specified song
    SELECT AVG(rating) INTO avgRating
    FROM user_ratings
    WHERE song_id = songId;

    RETURN avgRating;  -- Return the average rating
END $$

-- Procedure to get comments for an album
CREATE PROCEDURE GetAlbumComments(IN albumId INT)
BEGIN
    -- Validate input parameters
    IF albumId IS NULL THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Invalid input parameter for GetAlbumComments';
    END IF;

    -- Select comments for the specified album
    SELECT c.comment
    FROM user_comments c
    WHERE c.album_id = albumId;  -- Filter by album ID
END $$

-- Procedure to add a song to a playlist
CREATE PROCEDURE AddSongToPlaylist(IN songId INT, IN playlistId INT)
BEGIN
    -- Validate input parameters
    IF songId IS NULL OR playlistId IS NULL THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Invalid input parameters for AddSongToPlaylist';
    END IF;

    -- Insert the song into the playlist
    INSERT INTO playlist_songs (playlist_id, song_id) VALUES (playlistId, songId);
END $$

-- Procedure to rate a song
CREATE PROCEDURE RateSong(IN songId INT, IN userId INT, IN rating INT)
BEGIN
    -- Validate input parameters
    IF songId IS NULL OR userId IS NULL OR rating IS NULL OR rating < 1 OR rating > 5 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Invalid input parameters for RateSong';
    END IF;

    -- Insert or update the rating for the song by the user
    INSERT INTO user_ratings (song_id, user_id, rating) VALUES (songId, userId, rating)
    ON DUPLICATE KEY UPDATE rating = VALUES(rating);  -- Update rating if it exists
END $$

-- Procedure to add a favorite song
CREATE PROCEDURE AddFavoriteSong(IN userId INT, IN songId INT)
BEGIN
    -- Validate input parameters
    IF userId IS NULL OR songId IS NULL THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Invalid input parameters for AddFavoriteSong';
    END IF;

    -- Insert the song into the user's favorites
    INSERT INTO favorite_songs (user_id, song_id) VALUES (userId, songId);
END $$

-- Procedure to add a favorite album
CREATE PROCEDURE AddFavoriteAlbum(IN userId INT, IN albumId INT)
BEGIN
    -- Validate input parameters
    IF userId IS NULL OR albumId IS NULL THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Invalid input parameters for AddFavoriteAlbum';
    END IF;

    -- Insert the album into the user's favorites
    INSERT INTO favorite_albums (user_id, album_id) VALUES (userId, albumId);
END $$

-- Procedure to increment the play count of a song
CREATE PROCEDURE IncrementSongPlayCount(IN songId INT)
BEGIN
    -- Validate input parameters
    IF songId IS NULL THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Invalid input parameter for IncrementSongPlayCount';
    END IF;

    -- Insert or update the play count for the song
    INSERT INTO song_plays (song_id, play_count) VALUES (songId, 1)
    ON DUPLICATE KEY UPDATE play_count = play_count + 1;  -- Increment play count if it exists
END $$

-- Procedure to add an album review
CREATE PROCEDURE AddAlbumReview(IN albumId INT, IN userId INT, IN review TEXT, IN rating INT)
BEGIN
    -- Validate input parameters
    IF albumId IS NULL OR userId IS NULL OR rating IS NULL OR rating < 1 OR rating > 5 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Invalid input parameters for AddAlbumReview';
    END IF;

    -- Insert the review for the album by the user
    INSERT INTO album_reviews (album_id, user_id, review, rating) VALUES (albumId, userId, review, rating);
END $$

-- Procedure to share a playlist
CREATE PROCEDURE SharePlaylist(IN playlistId INT, IN userId INT, IN sharedWithUserId INT)
BEGIN
    -- Validate input parameters
    IF playlistId IS NULL OR userId IS NULL OR sharedWithUserId IS NULL THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Invalid input parameters for SharePlaylist';
    END IF;

    -- Insert the shared playlist record
    INSERT INTO shared_playlists (playlist_id, user_id, shared_with_user_id) VALUES (playlistId, userId, sharedWithUserId);
END $$

-- Reset the delimiter back to the default
DELIMITER ;