import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DbMusicCollectionManagerWeek7 {
    private static final Logger LOGGER = Logger.getLogger(DbMusicCollectionManagerWeek7.class.getName());

    // JDBC URLs and credentials
    private static final String READ_ONLY_URL = "jdbc:mysql://Macdizie@localhost:3306/MusicCollection?user=readonly_user&password=Arizona3003!$";
    private static final String MODIFY_URL = "jdbc:mysql://Macdizie@localhost:3306/MusicCollection?user=modify_user&password=Arizona3003!$";
    
    private static String DATABASE_URL;
    private static String DATABASE_USER;
    private static String DATABASE_PASSWORD;
    private static Connection connectionManager;

    // Default constructor
    public DbMusicCollectionManagerWeek7() {
        // Initialize connection properties if needed
    }

    // Method to get read-only connection
    public Connection getReadOnlyConnection() {
        try {
            return DriverManager.getConnection(READ_ONLY_URL);
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Failed to establish a read-only connection", e);
            return null;
        }
    }

    // Method to get modify connection
    public Connection getModifyConnection() {
        try {
            return DriverManager.getConnection(MODIFY_URL);
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Failed to establish a modification connection", e);
            return null;
        }
    }

    // Setters for database connection properties
    public static void setDatabaseUrl(String url) {
        DATABASE_URL = url;
    }

    public static void setDatabaseUser(String user) {
        DATABASE_USER = user;
    }

    public static void setDatabasePassword(String password) {
        DATABASE_PASSWORD = password;
    }

    // Method to get the connection manager
    public static Connection getConnectionManager() {
        if (connectionManager == null) {
            if (DATABASE_URL == null || DATABASE_USER == null || DATABASE_PASSWORD == null) {
                throw new IllegalStateException("Database connection properties are not set.");
            }
            try {
                connectionManager = DriverManager.getConnection(DATABASE_URL, DATABASE_USER, DATABASE_PASSWORD);
            } catch (SQLException e) {
                LOGGER.log(Level.SEVERE, "Failed to establish a connection", e);
            }
        }
        return connectionManager;
    }
}
