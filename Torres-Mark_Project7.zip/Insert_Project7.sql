-- Disable foreign key checks to avoid errors when dropping tables
SET FOREIGN_KEY_CHECKS = 0;

-- Drop existing tables if they exist to avoid errors during creation
DROP TABLE IF EXISTS SharedPlaylists;  -- Drop this first as it references Playlists
DROP TABLE IF EXISTS PlaylistSongs;    -- Drop this as it references Playlists
DROP TABLE IF EXISTS Reviews;          -- Drop this as it references Albums
DROP TABLE IF EXISTS Playlists;        -- Now drop Playlists after dependent tables
DROP TABLE IF EXISTS Songs;            -- Drop Songs table
DROP TABLE IF EXISTS Albums;           -- Drop Albums table
DROP TABLE IF EXISTS Artists;          -- Drop Artists table
DROP TABLE IF EXISTS Users;            -- Drop Users table

-- Re-enable foreign key checks after dropping tables
SET FOREIGN_KEY_CHECKS = 1;

-- Create the users table
CREATE TABLE Users (
    id INT AUTO_INCREMENT PRIMARY KEY,  -- Primary key for users table, auto-incremented
    username VARCHAR(255) NOT NULL UNIQUE,  -- Username, must be unique
    email VARCHAR(255) NOT NULL UNIQUE,  -- Email, must be unique
    password VARCHAR(255) NOT NULL  -- Password hash for authentication
);

-- Create the artists table
CREATE TABLE Artists (
    id INT AUTO_INCREMENT PRIMARY KEY,  -- Primary key for artists table, auto-incremented
    name VARCHAR(255) NOT NULL,  -- Name of the artist, cannot be null
    biography TEXT,  -- Biography of the artist
    social_media_links TEXT  -- Social media links for the artist
);

-- Create the albums table
CREATE TABLE Albums (
    id INT AUTO_INCREMENT PRIMARY KEY,  -- Primary key for albums table, auto-incremented
    title VARCHAR(255) NOT NULL,  -- Title of the album, cannot be null
    artist_id INT NOT NULL,  -- Foreign key referencing the artists table
    release_year INT NOT NULL,  -- Release year of the album, cannot be null
    genre VARCHAR(100),  -- Genre of the album
    label VARCHAR(100),  -- Record label of the album
    FOREIGN KEY (artist_id) REFERENCES Artists(id) ON DELETE CASCADE  -- Foreign key constraint on artist_id
);

-- Create the songs table
CREATE TABLE Songs (
    id INT AUTO_INCREMENT PRIMARY KEY,  -- Primary key for songs table, auto-incremented
    album_id INT,  -- Foreign key referencing the albums table
    title VARCHAR(255) NOT NULL,  -- Title of the song, cannot be null
    duration TIME,  -- Duration of the song
    lyrics TEXT,  -- Lyrics of the song
    composer VARCHAR(255),  -- Composer of the song
    producer VARCHAR(255),  -- Producer of the song
    FOREIGN KEY (album_id) REFERENCES Albums(id) ON DELETE CASCADE  -- Foreign key constraint on album_id
);

-- Create the playlists table
CREATE TABLE Playlists (
    id INT AUTO_INCREMENT PRIMARY KEY,  -- Primary key for playlists table, auto-incremented
    user_id INT NOT NULL,  -- Foreign key referencing the users table
    name VARCHAR(255) NOT NULL,  -- Name of the playlist, cannot be null
    description TEXT,  -- Description of the playlist
    FOREIGN KEY (user_id) REFERENCES Users(id) ON DELETE CASCADE  -- Foreign key constraint on user_id
);

-- Create the playlist_songs table
CREATE TABLE PlaylistSongs (
    playlist_id INT,  -- Foreign key referencing the playlists table
    song_id INT,  -- Foreign key referencing the songs table
    PRIMARY KEY (playlist_id, song_id),  -- Composite primary key
    FOREIGN KEY (playlist_id) REFERENCES Playlists(id) ON DELETE CASCADE,  -- Foreign key constraint on playlist_id
    FOREIGN KEY (song_id) REFERENCES Songs(id) ON DELETE CASCADE  -- Foreign key constraint on song_id
);

-- Create the reviews table
CREATE TABLE Reviews (
    id INT AUTO_INCREMENT PRIMARY KEY,  -- Primary key for reviews table, auto-incremented
    album_id INT,  -- Foreign key referencing the albums table
    user_id INT,  -- Foreign key referencing the users table
    review TEXT,  -- Review text
    rating INT CHECK (rating >= 1 AND rating <= 5),  -- Rating between 1 and 5
    FOREIGN KEY (album_id) REFERENCES Albums(id) ON DELETE CASCADE,  -- Foreign key constraint on album_id
    FOREIGN KEY (user_id) REFERENCES Users(id) ON DELETE CASCADE  -- Foreign key constraint on user_id
);

-- Create the shared_playlists table
CREATE TABLE SharedPlaylists (
    playlist_id INT,  -- Foreign key referencing the playlists table
    user_id INT,  -- Foreign key referencing the users table
    shared_with_user_id INT,  -- Foreign key referencing the users table for the user with whom the playlist is shared
    PRIMARY KEY (playlist_id, user_id, shared_with_user_id),  -- Composite primary key
    FOREIGN KEY (playlist_id) REFERENCES Playlists(id) ON DELETE CASCADE,  -- Foreign key constraint on playlist_id
    FOREIGN KEY (user_id) REFERENCES Users(id) ON DELETE CASCADE,  -- Foreign key constraint on user_id
    FOREIGN KEY (shared_with_user_id) REFERENCES Users(id) ON DELETE CASCADE  -- Foreign key constraint on shared_with_user_id
);

-- Inserting data into Users table
INSERT INTO Users (username, email, password) VALUES
('john_doe', 'john@example.com', SHA2('securepassword123', 256)),
('jane_doe', 'jane@example.com', SHA2('anothersecurepassword', 256));

-- Inserting data into Artists table
INSERT INTO Artists (name, biography, social_media_links) VALUES
('The Beatles', 'Legendary British rock band', '@thebeatles'),
('Adele', 'British singer and songwriter', '@adele');

-- Inserting data into Albums table
INSERT INTO Albums (title, artist_id, release_year, genre, label) VALUES
('Abbey Road', 1, 1969, 'Rock', 'Apple Records'),
('25', 2, 2015, 'Pop', 'XL Recordings');

-- Inserting data into Songs table
INSERT INTO Songs (album_id, title, duration, composer, producer) VALUES
(1, 'Come Together', '00:04:20', 'John Lennon', 'George Martin'),
(2, 'Hello', '00:04:55', 'Adele Adkins', 'Greg Kurstin');

-- Inserting data into Reviews table
INSERT INTO Reviews (album_id, user_id, review, rating) VALUES
(1, 1, 'Amazing album!', 5),
(2, 2, 'Adele never disappoints!', 4);

-- Inserting data into Playlists table
INSERT INTO Playlists (user_id, name, description) VALUES
(1, 'My Rock Playlist', 'Best rock songs'),
(2, 'Chill Vibes', 'Relaxing music');

-- Inserting data into SharedPlaylists table
INSERT INTO SharedPlaylists (playlist_id, user_id, shared_with_user_id) VALUES
(1, 1, 2),
(2, 2, 1);

-- Inserting data into PlaylistSongs table
INSERT INTO PlaylistSongs (playlist_id, song_id) VALUES
(1, 1),
(2, 2);
