/**
 * The Mainweek7 class serves as the entry point for the music collection application.
 * It initializes the application, configures logging, and starts the main application loop.
 */

 import java.util.logging.Level;
 import java.util.logging.Logger;
 
 public class Mainweek7 {
     private static final Logger LOGGER = Logger.getLogger(Mainweek7.class.getName());
 
     
     /**
      * The main method initializes and runs the music collection application.
      *
      * @param args Command-line arguments (not used).
      */
     public static void main(String[] args) {
         try {
             // Initialize application configurations
             
             // Set up logging configurations
             initializeLogging();
             
             // Load necessary configurations for the application
             loadConfigurations();
 
             // Welcome message
             
             // Display a welcome message to the user
             displayWelcomeMessage();
 
             // Run the application
             MusicCollectionAppweek7 app = new MusicCollectionAppweek7();
             app.run();
 
             // Add a shutdown hook for graceful termination
             addShutdownHook();
 
         } catch (Exception e) {
             LOGGER.log(Level.SEVERE, "An unexpected error occurred: ", e);
             System.err.println("An unexpected error occurred: " + e.getMessage());
         }
     }
 
     private static void initializeLogging() {
         // Set up logging configurations (e.g., to file or console)
         LOGGER.setLevel(Level.INFO);
         // Configure logging to file or other destinations if needed
         System.out.println("Logging initialized.");
     }
 
     private static void loadConfigurations() {
         // Load application configurations (e.g., from a file or environment variables)
         System.out.println("Configurations loaded.");
     }
 
     private static void displayWelcomeMessage() {
         System.out.println("\nWelcome to the Music Collection Manager!");
         System.out.println("=======================================");
         System.out.println("Manage your music collection with ease.");
     }
 
     private static void addShutdownHook() {
         Runtime.getRuntime().addShutdownHook(new Thread(() -> {
             System.out.println("Shutting down gracefully...");
             // Perform any cleanup tasks here (e.g., closing resources)
             // Ensure this block completes quickly to avoid delaying shutdown
             LOGGER.info("Application terminated.");
         }));
     }
 }
 