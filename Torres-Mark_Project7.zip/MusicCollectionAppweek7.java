/**
 * The MusicCollectionAppweek7 class handles the user interface of the music collection application.
 * It interacts with the user, processes inputs, and calls business logic methods accordingly.
 */

 import java.util.Scanner;

 public class MusicCollectionAppweek7 {
     private MusicCollectionBusinessLogicWeek7 logic;
     private Scanner scanner;
 
     public MusicCollectionAppweek7() {
         logic = new MusicCollectionBusinessLogicWeek7();
         scanner = new Scanner(System.in);
     }
 
     /**
      * The run method is the main loop of the application. It displays the menu,
      * gets the user's choice, and processes the choice by calling appropriate methods.
      */
     public void run() {
         int choice;
         do {
             displayMenu();
             choice = getValidChoice();
             handleMenuChoice(choice);
         } while (choice != 0);
     }
 
     /**
      * The displayMenu method presents the user with available options.
      */
     private void displayMenu() {
         System.out.println("\n--- Music Collection Menu ---");
         System.out.println("1. View all songs");
         System.out.println("2. Add a new song");
         System.out.println("3. Update a song title");
         System.out.println("4. Delete a song");
         System.out.println("5. Search songs by artist");
         System.out.println("0. Exit");
         System.out.print("Enter your choice: ");
     }
 
     /**
      * The getValidChoice method gets a valid menu choice from the user.
      *
      * @return The user's choice as an integer.
      */
     private int getValidChoice() {
         while (!scanner.hasNextInt()) {
             System.out.println("Invalid input. Please enter a number.");
             scanner.next();
             System.out.print("Enter your choice: ");
         }
         return scanner.nextInt();
     }
 
     private void handleMenuChoice(int choice) {
         switch (choice) {
             case 1:
                 logic.printAllSongs();
                 break;
             case 2:
                 addNewSong();
                 break;
             case 3:
                 updateSongTitle();
                 break;
             case 4:
                 deleteSong();
                 break;
             case 5:
                 searchSongsByArtist();
                 break;
             case 0:
                 System.out.println("Exiting... Goodbye!");
                 break;
             default:
                 System.out.println("Invalid choice. Please try again.");
         }
     }
 
     private void addNewSong() {
         System.out.print("Enter song title: ");
         String title = scanner.next();
         System.out.print("Enter album ID: ");
         int albumId = getValidInteger();
         logic.addNewSong(title, albumId);
     }
 
     private void updateSongTitle() {
         System.out.print("Enter song ID to update: ");
         int songId = getValidInteger();
         System.out.print("Enter new title: ");
         String newTitle = scanner.next();
         logic.updateSongTitle(songId, newTitle);
     }
 
     private void deleteSong() {
         System.out.print("Enter song ID to delete: ");
         int songId = getValidInteger();
         logic.deleteSong(songId);
     }
 
     private void searchSongsByArtist() {
         System.out.print("Enter artist name: ");
         String artistName = scanner.next();
         logic.printSongsByArtist(artistName);
     }
 
     private int getValidInteger() {
         while (!scanner.hasNextInt()) {
             System.out.println("Invalid input. Please enter a number.");
             scanner.next();
             System.out.print("Enter a valid number: ");
         }
         return scanner.nextInt();
     }
 
     public static void main(String[] args) {
         MusicCollectionAppweek7 app = new MusicCollectionAppweek7();
         app.run();
     }
 }
 