/**
 * The MusicCollectionBusinessLogicWeek7 class encapsulates the business logic for the music collection application.
 * It interacts with the data access layer (DAL) to retrieve and manipulate data.
 */

 import java.sql.ResultSet;
 import java.sql.SQLException;
 
 public class MusicCollectionBusinessLogicWeek7 {
     private MusicCollectionDALWeek7 dal;
 
     public MusicCollectionBusinessLogicWeek7() {
         dal = new MusicCollectionDALWeek7();
     }
 
     // Method to retrieve all songs
     
     /**
      * The printAllSongs method retrieves and prints all songs in the music collection.
      * It interacts with the DAL to fetch song data and handles any SQL exceptions that may occur.
      */
     public void printAllSongs() {
         try (ResultSet rs = 
             // Fetch all songs from the database using the DAL
             dal.getAllSongs()) {
             if (rs != null) {
                 while (rs.next()) {
                     System.out.println("Song ID: " + rs.getInt("id") + ", Title: " + rs.getString("title"));
                 }
             } else {
                 System.out.println("No songs found.");
             }
         } catch (SQLException e) {
             System.err.println("Error printing songs: " + e.getMessage());
         }
     }
 
     // Method to add a new song
     public void addNewSong(String title, int albumId) {
         try {
             dal.addSong(title, albumId);
             System.out.println("Song added successfully.");
         } catch (SQLException e) {
             System.err.println("Error adding song: " + e.getMessage());
         }
     }
 
     // Method to update a song's title
     public void updateSongTitle(int songId, String newTitle) {
         try {
             dal.updateSongTitle(songId, newTitle);
             System.out.println("Song title updated successfully.");
         } catch (SQLException e) {
             System.err.println("Error updating song title: " + e.getMessage());
         }
     }
 
     // Method to delete a song
     public void deleteSong(int songId) {
         try {
             dal.deleteSong(songId);
             System.out.println("Song deleted successfully.");
         } catch (SQLException e) {
             System.err.println("Error deleting song: " + e.getMessage());
         }
     }
 
     // Method to retrieve songs by artist
     public void printSongsByArtist(String artistName) {
         try (ResultSet rs = dal.getSongsByArtist(artistName)) {
             if (rs != null) {
                 while (rs.next()) {
                     System.out.println("Song ID: " + rs.getInt("id") + ", Title: " + rs.getString("title"));
                 }
             } else {
                 System.out.println("No songs found for artist: " + artistName);
             }
         } catch (SQLException e) {
             System.err.println("Error retrieving songs by artist: " + e.getMessage());
         }
     }
 
     // Overloaded method to add a new song without an album ID
     public void addNewSong(String title) {
         addNewSong(title, 1);
     }
 }