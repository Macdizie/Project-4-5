import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class MusicCollectionDALWeek7 {
    private static final Logger LOGGER = Logger.getLogger(MusicCollectionDALWeek7.class.getName());

    // JDBC URLs and credentials for read-only and modification users
    private static final String READ_ONLY_URL = "jdbc:mysql://Macdizie@localhost:3306/MusicCollection";
    private static final String READ_ONLY_USER = "readonly_user";
    private static final String READ_ONLY_PASSWORD = "Arizona3003!$";

    private static final String MODIFICATION_URL = "jdbc:mysql://Macdizie@localhost:3306/MusicCollection";
    private static final String MODIFICATION_USER = "modification_user";
    private static final String MODIFICATION_PASSWORD = "Arizona3003!$";

    // Method to establish a connection for read-only operations
    private Connection getReadOnlyConnection() throws SQLException {
        return DriverManager.getConnection(READ_ONLY_URL, READ_ONLY_USER, READ_ONLY_PASSWORD);
    }

    // Method to establish a connection for modification operations
    private Connection getModificationConnection() throws SQLException {
        return DriverManager.getConnection(MODIFICATION_URL, MODIFICATION_USER, MODIFICATION_PASSWORD);
    }

    // Example method to execute a read-only query
    public void executeReadOnlyQuery(String query) {
        try (Connection conn = getReadOnlyConnection();
             PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {
            // Process the ResultSet
            while (rs.next()) {
                // Handle the result set (e.g., print results)
            }
        } catch (SQLException ex) {
            LOGGER.log(Level.SEVERE, "Error executing read-only query", ex);
        }
    }

    // Example method to execute a modification query
    public void executeModificationQuery(String query) {
        try (Connection conn = getModificationConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            // Execute the update/insert/delete query
            int affectedRows = stmt.executeUpdate();
            // Handle the outcome if needed
        } catch (SQLException ex) {
            LOGGER.log(Level.SEVERE, "Error executing modification query", ex);
        }
    }
}
