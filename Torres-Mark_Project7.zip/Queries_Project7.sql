-- Drop tables if they exist to ensure clean creation
DROP TABLE IF EXISTS user_ratings, user_comments, favorite_songs, favorite_albums, 
                     song_plays, album_reviews, shared_playlists, reviews, playlist_songs, 
                     playlists, users, songs, albums, artists;

-- Drop stored procedures and functions if they exist
DROP PROCEDURE IF EXISTS GetTopRatedSongs;
DROP PROCEDURE IF EXISTS GetAlbumComments;
DROP PROCEDURE IF EXISTS GetFavoriteSongs;
DROP PROCEDURE IF EXISTS GetFavoriteAlbums;
DROP FUNCTION IF EXISTS calculate_avg_rating;

-- Create the artists table
CREATE TABLE artists (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    biography TEXT,
    social_media_links TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create the albums table
CREATE TABLE albums (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    artist_id INT NOT NULL,
    release_date DATE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (artist_id) REFERENCES artists(id) ON DELETE CASCADE
);

-- Create the users table
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create the songs table
CREATE TABLE songs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    album_id INT NOT NULL,
    artist_id INT NOT NULL,
    duration TIME NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (album_id) REFERENCES albums(id) ON DELETE CASCADE,
    FOREIGN KEY (artist_id) REFERENCES artists(id) ON DELETE CASCADE
);

-- Create the playlists table
CREATE TABLE playlists (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create the user_ratings table
CREATE TABLE user_ratings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    song_id INT NOT NULL,
    rating DECIMAL(2, 1) NOT NULL CHECK (rating >= 1.0 AND rating <= 5.0),
    review TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (song_id) REFERENCES songs(id) ON DELETE CASCADE
);

-- Create the user_comments table
CREATE TABLE user_comments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    album_id INT NOT NULL,
    comment TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (album_id) REFERENCES albums(id) ON DELETE CASCADE
);

-- Create the favorite_songs table
CREATE TABLE favorite_songs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    song_id INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (song_id) REFERENCES songs(id) ON DELETE CASCADE
);

-- Create the favorite_albums table
CREATE TABLE favorite_albums (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    album_id INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (album_id) REFERENCES albums(id) ON DELETE CASCADE
);

-- Create the song_plays table
CREATE TABLE song_plays (
    id INT AUTO_INCREMENT PRIMARY KEY,
    song_id INT NOT NULL,
    play_count INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (song_id) REFERENCES songs(id) ON DELETE CASCADE
);

-- Create the album_reviews table
CREATE TABLE album_reviews (
    id INT AUTO_INCREMENT PRIMARY KEY,
    album_id INT NOT NULL,
    review TEXT NOT NULL,
    rating DECIMAL(2, 1) NOT NULL CHECK (rating >= 1.0 AND rating <= 5.0),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (album_id) REFERENCES albums(id) ON DELETE CASCADE
);

-- Create the shared_playlists table
CREATE TABLE shared_playlists (
    id INT AUTO_INCREMENT PRIMARY KEY,
    playlist_id INT NOT NULL,
    shared_with_user_id INT NOT NULL,
    shared_by_user_id INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (playlist_id) REFERENCES playlists(id) ON DELETE CASCADE,
    FOREIGN KEY (shared_with_user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (shared_by_user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Create the reviews table
CREATE TABLE reviews (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    album_id INT NOT NULL,
    review TEXT NOT NULL,
    rating DECIMAL(2, 1) NOT NULL CHECK (rating >= 1.0 AND rating <= 5.0),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (album_id) REFERENCES albums(id) ON DELETE CASCADE
);

-- Create the playlist_songs table
CREATE TABLE playlist_songs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    playlist_id INT NOT NULL,
    song_id INT NOT NULL,
    added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (playlist_id) REFERENCES playlists(id) ON DELETE CASCADE,
    FOREIGN KEY (song_id) REFERENCES songs(id) ON DELETE CASCADE
);

-- Create a function to calculate the average rating of an album
DELIMITER $$
CREATE FUNCTION calculate_avg_rating(albumID INT)
RETURNS DECIMAL(3, 2)
DETERMINISTIC
BEGIN
    DECLARE avg_rating DECIMAL(3, 2);
    SELECT AVG(rating) INTO avg_rating
    FROM reviews
    WHERE album_id = albumID;
    RETURN avg_rating;
END $$
DELIMITER ;

-- Create the GetTopRatedSongs stored procedure
DELIMITER $$
CREATE PROCEDURE GetTopRatedSongs(IN albumID INT, IN limitCount INT)
BEGIN
    SELECT songs.title, AVG(user_ratings.rating) AS average_rating
    FROM songs
    JOIN user_ratings ON songs.id = user_ratings.song_id
    WHERE songs.album_id = albumID
    GROUP BY songs.title
    ORDER BY average_rating DESC
    LIMIT limitCount;
END $$
DELIMITER ;

-- Create the GetAlbumComments stored procedure
DELIMITER $$
CREATE PROCEDURE GetAlbumComments(IN albumID INT)
BEGIN
    SELECT albums.title, user_comments.comment
    FROM user_comments
    JOIN albums ON user_comments.album_id = albums.id
    WHERE albums.id = albumID;
END $$
DELIMITER ;

-- Create the GetFavoriteSongs stored procedure
DELIMITER $$
CREATE PROCEDURE GetFavoriteSongs(IN userID INT)
BEGIN
    SELECT songs.title
    FROM favorite_songs
    JOIN songs ON favorite_songs.song_id = songs.id
    WHERE favorite_songs.user_id = userID;
END $$
DELIMITER ;

-- Create the GetFavoriteAlbums stored procedure
DELIMITER $$
CREATE PROCEDURE GetFavoriteAlbums(IN userID INT)
BEGIN
    SELECT albums.title
    FROM favorite_albums
    JOIN albums ON favorite_albums.album_id = albums.id
    WHERE favorite_albums.user_id = userID;
END $$
DELIMITER ;

-- Queries
-- 1. Select all albums from the albums table with their artist's name
SELECT albums.title AS album_name, artists.name AS artist_name
FROM albums
JOIN artists ON albums.artist_id = artists.id;

-- 2. Select all songs from the songs table
SELECT * FROM songs;

-- 3. Select all playlists from the playlists table
SELECT * FROM playlists;

-- 4. Select all songs in a specific playlist
SELECT playlists.name AS playlist_name, songs.title AS song_title
FROM playlist_songs
JOIN playlists ON playlist_songs.playlist_id = playlists.id
JOIN songs ON playlist_songs.song_id = songs.id;

-- 5. Select all user ratings from the user_ratings table
SELECT * FROM user_ratings;

-- 6. Select all user comments from the user_comments table
SELECT * FROM user_comments;

-- 7. Retrieve top 3 songs for a specific album by rating
CALL GetTopRatedSongs(1, 3); -- Replace 1 with the desired album ID and 3 with the desired limit count

-- 8. Retrieve comments for a specific album
CALL GetAlbumComments(1); -- Replace 1 with the desired album ID

-- 9. Select all favorite songs of a user
CALL GetFavoriteSongs(1); -- Replace 1 with the desired user ID

-- 10. Select all favorite albums of a user
CALL GetFavoriteAlbums(1); -- Replace 1 with the desired user ID

-- 11. Select play count of all songs
SELECT songs.title, song_plays.play_count
FROM song_plays
JOIN songs ON song_plays.song_id = songs.id;

-- 12. Select all album reviews
SELECT albums.title AS album_name, album_reviews.review, album_reviews.rating
FROM album_reviews
JOIN albums ON album_reviews.album_id = albums.id;

-- 13. Select shared playlists of a user
SELECT playlists.name, users.username AS shared_by
FROM shared_playlists
JOIN playlists ON shared_playlists.playlist_id = playlists.id
JOIN users ON shared_playlists.shared_by_user_id = users.id
WHERE shared_playlists.shared_with_user_id = 2; -- Replace 2 with the desired user ID

-- 14. Select artist information
SELECT name, biography, social_media_links
FROM artists;

-- 15. Query to get the average rating of a specific album
SELECT calculate_avg_rating(1) AS avg_rating;