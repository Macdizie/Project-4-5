
# Music Collection Management Application

## Overview
This application is designed to manage a music collection. It allows users to retrieve album names by artist, assign songs to playlists, and interact with a database through a command-line interface.

## Prerequisites
- Java Development Kit (JDK) 8 or higher
- A MySQL database with the appropriate schema set up using the provided SQL scripts

## Files
- `DbMusicCollectionManager.java`: Manages database connections.
- `Main.java`: The entry point of the application.
- `MusicCollectionApp.java`: Handles user interactions.
- `MusicCollectionBusinessLogic.java`: Implements the core business logic.
- `MusicCollectionDAL.java`: Manages data access logic.
- `Create_Database_Project4.sql`: Script to create the database schema.
- `Create_Functions_Project4.sql`: Script to create stored procedures.
- `Insert_Project4.sql`: Script to insert sample data.
- `Queries_Project4.sql`: Script containing sample queries.

## Setup Instructions

1. **Database Setup**:
   - Use the `Create_Database_Project4.sql` script to create the necessary database schema.
   - Use the `Create_Functions_Project4.sql` script to create the stored procedures.
   - Use the `Insert_Project4.sql` script to populate the database with sample data.

2. **Compile the Java Files**:
   - Open a terminal or command prompt.
   - Navigate to the directory containing the Java files.
   - Run the following command to compile all the Java files:
     ```bash
     javac *.java
     ```

3. **Run the Application**:
   - After compiling, run the application using:
     ```bash
     java Main
     ```
   - Follow the on-screen prompts to interact with the application.

## Usage
- The application provides a menu with options to:
  1. Retrieve album names by artist.
  2. Assign a song to a playlist.
  3. Exit the application.

## Notes
- Ensure the database credentials are correctly set in the `DbMusicCollectionManager` class before running the application.
- Modify the SQL scripts as needed to match your database setup.

## Troubleshooting
- If you encounter any issues with database connectivity, verify your JDBC URL, username, and password in the `DbMusicCollectionManager` class.
- Ensure that your MySQL server is running and accessible.

## License
This project is provided as-is without any warranties. Feel free to modify and distribute as needed.
