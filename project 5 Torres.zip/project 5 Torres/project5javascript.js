// Constants for API setup and DOM element selection
const API_KEY = "732f5403822646ba95864727240112"; // API key for accessing the weather service
const BASE_URL = "http://api.weatherapi.com/v1"; // Weather API base endpoint
const weatherOutput = document.getElementById("weather-output"); // Element to display current weather details
const forecastOutput = document.getElementById("forecast-output"); // Element reserved for forecast data (not yet used)

// Add listener to process user input for weather search
document.getElementById("weather-form").addEventListener("submit", handleWeather);

// Add listener for fetching weather data based on the user's current location
document.getElementById("current-location-btn").addEventListener("click", getCurrentLocationWeather);

// Handles the process when a user searches for weather by input
function handleWeather(event) {
    event.preventDefault(); // Stop the default form submission behavior
    const location = document.getElementById("location").value.trim(); // Retrieve user input and remove extra spaces
    if (!location) {
        alert("Please enter a city or ZIP code."); // Alert the user if no input is provided
        return; // Exit function if the input is empty
    }
    getWeatherData(location); // Retrieve weather data for the provided input
}

// Fetches weather data using the user's current geographic coordinates
function getCurrentLocationWeather() {
    if (navigator.geolocation) {
        // Check if geolocation is supported by the browser
        navigator.geolocation.getCurrentPosition(
            (position) => {
                // On success, retrieve latitude and longitude
                const { latitude, longitude } = position.coords; // Extract coordinates
                getWeatherDataByCoordinates(latitude, longitude); // Fetch weather using coordinates
            },
            (error) => {
                // Handle errors from geolocation
                alert("Geolocation error: " + error.message); // Inform the user of the error
            }
        );
    } else {
        alert("Geolocation is not supported by your browser."); // Notify if geolocation is unavailable
    }
}

// Retrieves weather data for a specific location via API
async function getWeatherData(location) {
    try {
        const weatherResponse = await fetch(`${BASE_URL}/current.json?key=${API_KEY}&q=${location}`); // Call the API
        if (!weatherResponse.ok) throw new Error("Error fetching weather data."); // Handle unsuccessful responses
        const weatherData = await weatherResponse.json(); // Parse the API response as JSON
        displayCurrentWeather(weatherData); // Show the weather data on the web page
    } catch (error) {
        console.error("Error fetching weather data:", error); // Log errors for debugging
        alert("An error occurred while fetching weather data. Please try again."); // Notify the user of the error
    }
}

// Fetches weather data based on latitude and longitude via API
async function getWeatherDataByCoordinates(lat, lon) {
    try {
        const weatherResponse = await fetch(`${BASE_URL}/current.json?key=${API_KEY}&q=${lat},${lon}`); // Call the API using coordinates
        if (!weatherResponse.ok) throw new Error("Error fetching weather data."); // Handle unsuccessful responses
        const weatherData = await weatherResponse.json(); // Parse the API response as JSON
        displayCurrentWeather(weatherData); // Show the weather data on the web page
    } catch (error) {
        console.error("Error fetching weather data by coordinates:", error); // Log errors for debugging
        alert("An error occurred while fetching weather data. Please try again."); // Notify the user of the error
    }
}

// Displays the current weather data in the designated section of the page
function displayCurrentWeather(data) {
    weatherOutput.classList.add("show"); // Make the weather output section visible
    weatherOutput.innerHTML = `
        <h2>Current Weather</h2>
        <p>Location: ${data.location.name}, ${data.location.region}</p> <!-- Show the location name and region -->
        <p>Temperature: ${data.current.temp_f}°F</p> <!-- Display the current temperature in Fahrenheit -->
        <p>Weather: ${data.current.condition.text}</p> <!-- Describe the current weather condition -->
        <p>Humidity: ${data.current.humidity}%</p> <!-- Show the humidity percentage -->
        <p>Wind Speed: ${data.current.wind_mph} mph ${data.current.wind_dir}</p> <!-- Display the wind speed and direction -->
        <p>Forecast: Mostly clear, with a low around ${data.current.feelslike_f}°F. ${data.current.wind_dir} wind around ${data.current.wind_mph} mph.</p> <!-- Provide a brief weather summary -->
    `;
}